/**
 * Created by Karimnassif on 5/1/2016.
 */
public class Reflector {

    char[] setup;

    public Reflector(char[] a){  //constructor
        this.setup=a;
    }

}
